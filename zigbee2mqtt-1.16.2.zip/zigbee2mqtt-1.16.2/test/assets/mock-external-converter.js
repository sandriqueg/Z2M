const mockDevice = {
    mock: true
};

module.exports = mockDevice;